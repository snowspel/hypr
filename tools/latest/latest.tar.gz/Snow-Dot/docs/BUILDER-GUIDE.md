# snow: builder guide (Hyprland + Quickshell)

For the AI that turns designs into the real desktop. Read this fully before touching any file. It is written from many real mistakes, so every rule here cost time once.

Updated 2026-10-15, package Snow-Dot-v1 (numbering restarted at v1 on 2026-10-15; old v42 was the last of the old numbering). Full history and all code: `claude/snow-hyprland.txt` (Project doc, also in the tarball). Short state: `claude/handoff.md`. Design rules for the designer AI: `docs/Instruction.md`.

---

## 1. The person you work for

- Not a coder. Writes Hinglish. Only copy-pastes terminal commands. Trusts your judgement: choose a sensible default, say what you chose, move on.
- Every instruction to the user is a ready-to-paste command block plus one line saying what it does. Never "open the file and change line 40". Deliver finished files.
- **Delivery (his choice since 2026-10-14):** no new tarball for every change. Tiny edit = one `sed` line (test it first on a copy of the file you delivered before). Bigger change = a small patch `.tar.gz` with only the changed files plus one command that extracts and copies them. The full `Snow-Dot-vNN.tar.gz` only when he asks. Never ask him to paste long QML into the terminal.
- No third-party dotfiles. Everything is ours.
- Hard preferences: 12-hour clock with small AM/PM; month "October" not "OCTOBER"; **no lock button** in the power menu; pacman over flatpak; do not re-suggest features the user declined (list: "THINGS THE USER DID NOT WANT" in narrative.txt).

## 2. What is installed (facts, do not guess)

Arch, Hyprland **0.56.2 (Lua config)**, Quickshell **0.3.1**, SDDM 0.21 (Qt5 greeter), PipeWire, NVIDIA (open dkms), kitty, Nautilus, mpv (+ uosc interface, own config), Gwenview, Brave Origin, mission-center, hypridle + hyprlock. VLC is no longer used. User: `snow`, host `dk`.

The sandbox you work in **cannot run Hyprland or Quickshell**. You can only syntax-check. Say clearly what is untested, and give the user the exact test commands (section 9).

## 3. Layout and how pieces connect

```
Snow-Dot/
  install.sh  README.txt  tools/{snapshot,backup,restore,reset,doctor}.sh  tools/README.md  tools/latest/  backups/{backup,snapshot,history}/  docs/snow-hyprland.txt
  docs/  (START-HERE.md, BUILDER-GUIDE.md, Instruction.md, narrative.txt, make-doc.sh, snow-hyprland.txt)
  files/
    quickshell/         -> ~/.config/quickshell/snow/   (shell.qml, Theme.qml, components/*.qml)
    hypr/hyprland.lua   -> ~/.config/hypr/              (+ theme-colors.lua, look.lua)
    snow/               -> ~/.config/snow/              (bin/*.sh, themes/*.json, looks/*.json, fonts/, mpv/, power.json ...)
    sddm/snow/          -> /usr/share/sddm/themes/snow/ (login screen, Qt5)
    system/ extras/ wallpaper/ systemd/
```

- `shell.qml` (ShellRoot) loads one component per panel: Wallpaper, PowerMenu, QuickSettings, ThemeMenu, Launcher, NotificationPopups, OsdPopup, ClockOsd. Two more are loaded **by code** from a Timer (so a missing Quickshell module cannot break the whole shell): PolkitDialog and WorkspaceOsd. Helper files that are not panels: `SliderRow.qml` (used by Quick Settings), `WallpaperPreview.qml` (used by ThemeMenu through a Loader). `snow-doctor.sh` knows these exceptions.
- Panels open by keybind: Hyprland runs `qs -p ~/.config/quickshell/snow ipc call <target> toggle`. IPC targets: `launcher`, `power`, `control` (Quick Settings), `clock`, `themes`, `osd`. The workspace badge has no key: it watches `Hyprland.focusedWorkspace`.
- Colours come from `~/.config/snow/theme.json` through the `Theme` singleton (`import qs`). Scripts in `~/.config/snow/bin` do the real work (theme switch, wallpaper, audio, power, mpv-setup, backup ...). QML calls them; QML holds only look and light logic.
- Never edit the live files by hand and forget the repo: the repo (`Snow-Dot`) is the source. `install.sh` copies it to the system.

## 4. Quickshell rules (QML)

**Start / reload**
- Always `qs -p ~/.config/quickshell/snow`. `qs -c snow` never worked. Alias `snow`.
- **Restart command (use exactly this):** `pkill qs; sleep 1; nohup qs -p ~/.config/quickshell/snow > /tmp/qs.log 2>&1 & sleep 3; tail -30 /tmp/qs.log`. (`qs ... log` only prints an old log and does not start anything.)
- `Target not found` means an old instance is running: `pkill qs`, then start again.
- First line of `shell.qml` must stay: `//@ pragma UseQApplication` (tray menu needs it).
- Errors: `tail -30 /tmp/qs.log` or `qs -p ~/.config/quickshell/snow log | tail -30`.

**Panel skeleton (copy this pattern)**
```qml
import Quickshell
import Quickshell.Io
import Quickshell.Wayland
import QtQuick
import qs

PanelWindow {
    id: win
    visible: false
    color: "transparent"
    anchors { top: true; bottom: true; left: true; right: true }   // full screen layer; the visible card is a Rectangle inside
    exclusionMode: ExclusionMode.Ignore
    WlrLayershell.namespace: "snow-xyz"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: visible ? WlrKeyboardFocus.OnDemand : WlrKeyboardFocus.None   // Launcher / power use Exclusive

    IpcHandler { target: "xyz"; function toggle(): void { win.visible = !win.visible } }

    Item {
        anchors.fill: parent
        focus: true
        Keys.onEscapePressed: win.visible = false
        MouseArea { anchors.fill: parent; onClicked: win.visible = false }   // click outside closes
        // the card goes here
    }
}
```
- Click-through popups (OSD, notifications, clock, workspace badge): `mask: Region {}`.
- Register a new panel in `shell.qml`, add an IPC bind in `hyprland.lua`.

**Running commands**
- One-shot action: `Quickshell.execDetached(["cmd", "arg"])`. (Re-starting a `Process{}` that is already running fails silently.)
- Need the output: `Process { command: [...]; stdout: StdioCollector { onStreamFinished: text ... } }`, then `running = true`. Do not set it again while it runs.
- Scripts path: `Quickshell.env("HOME") + "/.config/snow/bin/"`.

**Things that broke before**
- `Component.onCompleted` on `ShellRoot` gives "Non-existent attached object" and kills the whole shell. Use a `Timer { running: true; repeat: false }`.
- Inline components work: `component Name: Type { ... }` (Quick Settings: Ms, Card, Lab, Pill, ConnPill, RailTile; Themes menu: Ms, Lab, Card, Btn, Switch, NumRow, ToggleRow, ChipRow, ColorPicker). Do not use `on` as a property name (reserved-looking); use `active`.
- Delegates: `required property var modelData` (objects) or `required property int modelData` (numbers); `required property int index`.
- Wallpaper image reload: add `?v=<mtime>` to `Image.source`.
- Do not use `Canvas` to draw icons any more. Use the icon font (section 7).
- Keep logic and look separate: if a designer changes a look, do not touch `Process`, functions or properties.
- A QML file that imports a module the PC may not have (`QtQuick.Effects`, Polkit, Hyprland) must not be part of a file that the whole shell needs: put it in its own file and load it with a `Loader` (ThemeMenu -> WallpaperPreview) or with `Qt.createComponent` from a Timer (shell.qml). A failed import then loses only that piece.
- Never rename an `id` with a blind `sed` over a big file (the same id can exist in another component). Use an exact-match edit with a count check, then check for duplicate ids.

**Layout lessons (real bugs)**
- The Quick Settings card is anchored to the **bottom**. If something inside it grows, the card grows **upwards** and everything near the top moves. A button at the top then jumps away from the mouse and the user "cannot close it".
- Rule: menus, dropdowns and option cards that open from a button must **float as an overlay** (own `z`, absolute `x/y` under the button) and must not change the card height. Close on: button again, click outside (a full-size `MouseArea` just under the overlay), Escape. Example: the Wi-Fi / Bluetooth list in Quick Settings floats at `content.y + connectSec.y + connectSec.height + 8`.
- Dropdown lists: `z` above neighbours; `MouseArea { anchors.fill: parent }` on the list so clicks do not fall through.
- Columns that must end level (Themes menu): put the last block at `y: parent.height - height` and let the flexible block (wallpaper card) take `lkLab.y - 12 - 22`. Do not leave a column shorter than its neighbour.
- A right edge must be the same for every row of a form (the editor form was 8 px short of the name box once): do not subtract "scrollbar" widths, Quickshell's Flickable draws none.

**Design language (since v40, from the owner's HTML designs)**
- Cards: radius 22-28, fill = `Qt.tint(Theme.surface, Qt.alpha(tintColor, 0.04))` at the top to `Theme.surface` at the bottom (`Gradient` with 2 stops). Panel: `Theme.bg` with `Qt.alpha(Theme.accent, 0.07)` at the top, border `Qt.alpha(Theme.accent, 0.24)`.
- Active tile / pill: accent gradient (`Qt.tint(Theme.accent, Qt.rgba(1,1,1,0.2))` to `Theme.accent`), white text, a soft ring (a bigger rounded rectangle behind it, `Qt.alpha(Theme.accent, 0.24)`).
- Section label: 6 px accent dot + 10 px bold spaced capitals in `Theme.muted`.
- Buttons are pills (radius = height / 2); hover = `Qt.tint(Theme.surfaceHi, Qt.alpha(Theme.tint, 0.08))`; pressed = scale 0.97.
- Fixed exceptions to "tokens only": the Shut Down tile is a fixed red when focused / hovered (owner's request), the workspace badge is a neutral dark glass.

**Colours in QML**
- Only tokens: `Theme.bg surface surfaceHi text muted accent warn danger success tint`. `tint` is white in dark mode and black in light mode: use `Qt.alpha(Theme.tint, 0.06)` for soft borders and hover.
- Pure white text on accent / danger is allowed (`"#ffffff"`); plain black veils `Qt.rgba(0, 0, 0, x)` too.
- No other hex colours anywhere (except the two exceptions above).

**Time and text**
- 12-hour clock: use `hour % 12 || 12` in JS. Qt's `h` format gives 24h. AM/PM small and next to it.

## 5. Hyprland 0.56 Lua rules (`hyprland.lua`)

The config is Lua on Hyprland 0.56.x (the old hyprlang syntax does not apply). Verify anything new against the current Hyprland wiki before using it; if the Hyprland version changes, re-check every `hl.*` call.

```lua
hl.on("hyprland.start", function ()
    hl.exec_cmd("bash " .. home .. "/.config/snow/bin/power.sh start")
end)

hl.env("NAME", "value")
hl.config({ misc = { key_press_enables_dpms = true }, input = { ... } })
hl.bind(mainMod .. " + T", hl.dsp.exec_cmd(terminal))
hl.bind("XF86AudioMute", hl.dsp.exec_cmd("..."), { locked = true, repeating = true })
hl.window_rule({ name = "x", match = { class = "^foo$" }, float = true, center = true, size = "900 600" })
```
- Logout: `hyprctl dispatch 'hl.dsp.exit()'` (the old `dispatch exit` does not work).
- Screen off / on: `hyprctl dispatch 'hl.dsp.dpms({ action = "off" })'` (the key is `action`).
- Other dispatchers seen working: `hl.dsp.window.close()`, `.fullscreen({ mode = "fullscreen" })`, `.float({ action = "toggle" })`, `hl.dsp.focus({ direction = "left" })`, `hl.dsp.focus({ workspace = 1 })`, `hl.dsp.layout("togglesplit")`.
- Check errors after a reload: `hyprctl configerrors`.
- `numlock_by_default` only once inside `input { }`.
- Existing keys: Super+T terminal, E files (new window), B browser, L LocalSend (so **never bind lock to Super+L**), Space launcher, Escape power menu, A Quick Settings, period clock, Shift+T themes, S / Shift+S screenshots.
- Keep `hyprland.lua` safe: the look file is loaded with `dofile` inside `pcall`.

## 6. Scripts and system changes

- Scripts must be re-runnable, never overwrite the user's saved settings (example: `power.json` is kept by `install.sh`; `mpv-setup.sh --keep` never overwrites), and back up before destructive changes.
- Background processes started from a script that asks questions: add `</dev/null` (they stole the terminal input once). Prompts read from `/dev/tty`.
- Every package name must be verified (`pacman -Si`). One wrong name stops a whole pacman transaction (`ttf-inter` is wrong, `inter-font` is right).
- Do not delete files in `/usr/share/applications` (they return on update); hide with a `NoDisplay=true` file in `~/.local/share/applications/`.
- NVIDIA: needs headers of every installed kernel; sleep needs `NVreg_PreserveVideoMemoryAllocations=1` and the three `nvidia-suspend/resume/hibernate` services enabled (+ reboot).
- Any feature that can lock the user out (lock screen, idle timers) must ship with a recovery line: Ctrl+Alt+F3, log in, `pkill hyprlock`.
- Add every new script/package to `tools/doctor.sh`, `install.sh`, backup/restore/reset when relevant (mpv is the model: files/snow/mpv, bin/mpv-setup.sh, install, restore --keep, snapshot, reset, doctor).

## 7. Icons (Google Material Symbols Rounded)

- Font file is bundled in `files/snow/fonts/` and installed by `bin/install-fonts.sh` (to `~/.local/share/fonts/snow`). Family name: `"Material Symbols Rounded"`. One static style (regular, not filled, size 24 base).
- Use **code points**, not names (no ligature needed): `text: ""`, `font.family: "Material Symbols Rounded"`, `font.pixelSize: 20-24`.
- Look up a name in `files/snow/fonts/MaterialSymbolsRounded.codepoints` (`name hex`). Verify every code point exists in the font file before shipping (a missing one shows an empty box); `fontTools` is available in the sandbox (`TTFont(...).getBestCmap()`).
- Examples: power `f8c7`, restart `f053`, logout `e9ba`, sleep `f159`, search `ef7a`, settings `e8b8`, wifi `e63e`, bluetooth `e1a7`, volume_up `e050`, volume_off `e04f`, brightness `e1ac`, check `e876`, close `e5cd`, expand_more `e5cf`, expand_less `e5ce`, wallpaper `e1bc`, edit `f097`, tune `e429`.
- The SDDM login screen cannot use this font (the sddm user cannot see the home folder). Keep its own drawing there.

## 8. Login screen (SDDM) lessons

- Real greeter is `/usr/bin/sddm-greeter`, **Qt5**. Test with `sddm-greeter --test-mode --theme /usr/share/sddm/themes/snow` (not the qt6 one).
- `import QtQuick 2.15` (with a version). `QtQuick.Effects` does not exist in Qt5: blur is pre-made with ImageMagick.
- Qt5 libs needed: `qt5-declarative qt5-quickcontrols2 qt5-graphicaleffects`.
- SDDM conf.d files are read alphabetically, the **later wins**; ours is `zz-snow.conf`.

## 9. Check and debug commands (give these to the user)

```
pkill qs; sleep 1; nohup qs -p ~/.config/quickshell/snow > /tmp/qs.log 2>&1 & sleep 3; tail -30 /tmp/qs.log    # restart + QML errors
hyprctl configerrors                                          # Lua config errors
bash ~/Snow-Dot/tools/doctor.sh | grep -E "WARN|FAIL|PASS:"    # health check
fc-list | grep -i "Material Symbols"                          # icon font installed
```
If a panel does not appear: `tail -30 /tmp/qs.log`, then check `IpcHandler` target name vs the keybind. If "nothing changed": check that the new code is really installed (`grep -c <a new word> ~/.config/quickshell/snow/components/<File>.qml`) before debugging anything else.

## 10. Turning the designer's HTML into QML

The designer delivers one self-contained HTML per panel with `data-el` names and a notes file (rules in `docs/Instruction.md`). Your job:
1. Read the HTML for sizes (px), radius, spacing, states (normal / hover / pressed / disabled 50%), and the notes.
2. Map CSS variables to `Theme.*` tokens (same names). No new colours.
3. Rebuild only the **look** in the existing component. Keep every `Process`, function, property and IPC handler. If the design needs a new behaviour, say so and add it deliberately. The HTML is a reference, not a spec to copy blindly: the owner may ask for changes (v40: one list per chevron instead of tabs).
4. Icons: Material Symbols names from the design -> code points (section 7).
5. Respect QML limits: no CSS blur on content, no backdrop-filter; shadows and blur need a plan (pre-render or skip, and tell the user).
6. Never ship a panel you did not at least brace-check. List what is untested.
7. The design HTML is not stored in the repo (there is no docs/design/ folder); the owner keeps his own copy. Describe the result in `docs/Instruction.md`.

## 11. Delivery workflow (every change)

1. Work in the working copy (a `Snow-Dot` folder). If a new chat has lost it: extract the newest `Snow-Dot-vNN.tar.gz`, apply later patch files, and restore `docs/narrative.txt` from the Project doc (everything before the APPENDIX banner of `docs/snow-hyprland.txt`).
2. `bash -n` every changed script; brace/paren balance, duplicate ids and icon code points for QML.
3. Update `docs/Instruction.md` (if a panel changed), `docs/narrative.txt` (next number), `README.txt`, `tools/README.md`, `tools/doctor.sh`, `install.sh`/restore/reset when needed.
4. `bash docs/make-doc.sh` (rebuilds `docs/snow-hyprland.txt`), then `project_write` it to `claude/snow-hyprland.txt`.
5. Deliver the change the way section 1 says (sed line / small patch / full tarball on request). Full tarball: `tar czf Snow-Dot-vNN.tar.gz --exclude='Snow-Dot/backups' --exclude='Snow-Dot/tools/latest' --exclude='Snow-Dot/.git' Snow-Dot` (next version number: v1, v2, v3 ...; numbering restarted on 2026-10-15).
6. In the chat, reply to the owner in Hinglish (chat only; every file stays English): what changed, the install commands (ending with a check), how to test, what is still untested.

User install flow for a full tarball: `tar xzf "$(find ~ -name 'Snow-Dot-vNN.tar.gz' -print -quit)" -C ~` then `bash ~/Snow-Dot/install.sh`, then the restart command (section 9).
Backups (all inside Snow-Dot): `tools/snapshot.sh` writes `backups/snapshot/`, `tools/backup.sh` writes `backups/backup/`, old `files/` copies go to `backups/history/`; the newest file is also kept as the single file `tools/latest/latest.tar.gz`, and `tools/restore.sh` with no name restores it. Nothing in `backups/` is deleted automatically. Details: `tools/README.md`.

## 12. Known open items

- `kitten failed with error: exit status 1` after a restore: not reproduced, parked.
- Bluetooth mouse wake not handled. Bluetooth disconnects on sleep (normal).
- SDDM icons do not use the icon font.

## 13. Starter message for a new chat

> Work inside the Hyprland Project. Read `claude/start-here.md`, `claude/builder-guide.md`, `claude/handoff.md` and `claude/snow-hyprland.txt`. Then I will send a design as HTML (or describe small changes), and you turn it into my snow Quickshell panel. Follow the rules of the guide, never say "done" for QML without running it in Quickshell, and tell me what is untested.
