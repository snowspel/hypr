# snow: START HERE (for a new AI, a new account, or a new chat)

This is the single entry point. If the old chat and the old account are gone, this folder (Snow-Dot) is enough to continue. Read this file first, then the others in the order below.

Updated 2026-10-15 (package Snow-Dot-v1; version numbers restarted at v1 on 2026-10-15, the old v42 was the last of the old numbering).

## 0. Reading order
1. `docs/START-HERE.md` (this file: the lessons, the do / do-not list, how to restart)
2. `docs/BUILDER-GUIDE.md` (exact rules and code patterns for Quickshell + Hyprland Lua)
3. `docs/Instruction.md` (every panel, sizes, theme tokens; the brief for a UI designer AI)
4. `docs/narrative.txt` (the full record: 90+ numbered changes, the mistakes log, technical lessons, things the user did not want)
5. `docs/snow-hyprland.txt` (narrative + the full code of every file)

Confidence tags used below: **[T]** tested on the owner's real PC, **[V]** checked in official docs during this project, **[M]** from memory or only syntax-checked (treat as a hypothesis).

## 1. The owner
Not a coder; writes Hinglish; copy-pastes commands. Trusts the AI's judgement. Wants his own desktop, no one else's dotfiles. Arch + Hyprland + Quickshell, user `snow`, host `dk`, NVIDIA GPU. Daily apps: Brave Origin, kitty, Nautilus, mission-center, AB Download Manager, mpv (with the uosc interface; VLC was removed), Gwenview.
He keeps a copy on a USB drive, and uses a second AI for UI design (HTML designs that this AI turns into QML).

## 2. How it works (the mental model)
- **Hyprland** is the compositor. Its config is **Lua** (`~/.config/hypr/hyprland.lua`, Hyprland 0.56.x). Autostart with `hl.on("hyprland.start", ...)`, keys with `hl.bind(...)`, window rules with `hl.window_rule({...})`. [T]
- **Quickshell** draws the panels in QML. Entry file `shell.qml`; each panel is a `PanelWindow` on the Wayland overlay layer; a rounded card is a transparent full-screen `PanelWindow` with a rounded `Rectangle` inside (this is also the official advice [V]).
- A panel opens by a Hyprland key that runs `qs -p ~/.config/quickshell/snow ipc call <target> toggle`; the panel has an `IpcHandler` with that target. Official docs describe the same idea (IpcHandler to show / hide) [V].
- Running commands: `Process` + `StdioCollector` to read output; `Quickshell.execDetached` for one-shot actions [V for Process/StdioCollector; T for the execDetached rule].
- Quickshell **reloads QML automatically when a file is saved** [V]; a full restart (command in BUILDER-GUIDE section 9) is still the safe way to test a changed install.
- Colours: one file `~/.config/snow/theme.json` -> `Theme.qml` singleton (10 tokens). Scripts (`bin/switch-theme.sh` and `apply-*.sh`) paint kitty, GTK, Qt and the lock screen from the same file. [T]
- Login screen: SDDM theme, **Qt5** greeter (not Qt6). [T]
- Sleep / lock: hypridle + hyprlock, configured by `bin/power.sh` and `bin/apply-lock.sh`; NVIDIA needs `PreserveVideoMemoryAllocations=1` and the nvidia-suspend services. [T for sleep, keyboard and mouse wake; M for hyprlock look]
- mpv: our config lives in `files/snow/mpv` and is put into `~/.config/mpv` by `bin/mpv-setup.sh` (which also downloads the uosc interface). install.sh and tools/restore.sh run it; tools/snapshot.sh copies the live mpv files back into the repo.
- Folder layout (v2): `install.sh`, `files/`, `docs/`, `tools/` (snapshot.sh, backup.sh, restore.sh, reset.sh, doctor.sh, README.md, latest/), `backups/` (backup/, snapshot/, history/). Everything stays inside Snow-Dot; nothing is written to `~/Snow-Backup`. `tools/latest/` holds exactly one file (latest.tar.gz). See `tools/README.md`. [T]

## 3. What the official documentation said (and what we could not confirm)
- Quickshell config lookup: a named subfolder of `~/.config/quickshell` that has a `shell.qml` is a config; `-c` picks it; `-p` takes any path [V]. **But on the owner's PC `qs -c snow` never worked, so always use `-p`** [T]. The reason is unknown.
- Quickshell FAQ [V]: use `Qt.resolvedUrl()` for paths relative to a QML file (string paths resolve against the working directory); use `Loader` / `LazyLoader` to create heavy objects only when needed; use `Repeater` for short lists and `ListView` for long ones; a transparent Rectangle with a `border` can make things beneath it disappear (Qt bug QTBUG-137166) and `border.width: 0` is the workaround. Our cards use a 1 px border on a filled colour and have shown no problem [T].
- Hyprland DPMS dispatch `hl.dsp.dpms({ action = "off" })` (key is `action`) was checked on the wiki [V] and works [T].
- The Hyprland wiki pages could not be fetched as text from the sandbox (binary content). So the `hl.*` calls in `hyprland.lua` come from the working config, not from a fresh read of the wiki. If something new is needed, ask the owner to paste the wiki text or test on the PC.
- hypridle option names (`ignore_dbus_inhibit` etc.) were written from memory and never confirmed [M].
- `QtQuick.Effects` (MultiEffect) is used for the rounded wallpaper picture in the Themes menu. It exists in Qt 6.5+, but it was never confirmed on the owner's PC [M]; it is loaded through a `Loader` so a missing module only loses the picture.
- Official links: https://quickshell.org/docs/ (guide, FAQ, types) and https://wiki.hypr.land/ (Hyprland wiki).

## 4. The mistakes (short list; details in narrative.txt PART 4)
| Mistake | Why it happened | Rule now |
|---|---|---|
| Wrong package names (`ttf-inter`) stopped a whole pacman run | guessed from memory | check with `pacman -Si`; right name `inter-font` |
| Pasting QML into the terminal | copy-paste by a non-coder | deliver files (patch tarball), never ask to paste long code |
| `Process` started again while running did nothing | Quickshell behaviour | `Quickshell.execDetached` for one-shot actions |
| `Component.onCompleted` on `ShellRoot` killed the shell | no attached object there | use a `Timer` |
| Logout command from the old Hyprland syntax | config is Lua now | `hyprctl dispatch 'hl.dsp.exit()'` |
| SDDM tested with the Qt6 greeter | assumed | the real greeter is Qt5: `sddm-greeter --test-mode ...`; `import QtQuick 2.15`; no `QtQuick.Effects` |
| `99-snow.conf` lost to `theme.conf` | digits sort before letters | name it `zz-snow.conf` |
| NVIDIA module "not found" | headers of the running kernel missing | install headers for every installed kernel |
| Backup missed files; second reset made an empty backup | no check | backup / reset / restore all check for real settings (`themes/`) |
| Invented a kitty flag (`--debug-config`) | from memory | never guess a flag; use `--help` or docs |
| Said a backup would be about 1 MB, it was 8 MB | estimate without measuring | measure first, or say "estimate" |
| Button at the top of a bottom-anchored card moved away when the card grew | layout grows upwards | menus open as floating overlays, never grow the card |
| Restore question skipped (background processes read the terminal) | stdin shared | `</dev/null` on background starts; prompts read from `/dev/tty` |
| Quick fix applied in the live system, not in the repo | forgot the source of truth | the repo is the source; every fix goes into the repo and the docs |
| Claimed "done" for QML that never ran | the sandbox cannot run Quickshell | always say what is untested and give the test commands |
| Told the owner to restart with `pkill qs; qs -p ... log`: `log` only prints the old log and does not start the shell, so "nothing changed" | wrong command | restart with `pkill qs; sleep 1; nohup qs -p ~/.config/quickshell/snow > /tmp/qs.log 2>&1 & sleep 3; tail -30 /tmp/qs.log` |
| A patch was sent but the owner never ran `install.sh` / the copy step | the instructions had no check | every install block ends with a check the owner can read (a `grep -c`, the doctor) |
| The working copy disappeared in a new chat (it lived in the sandbox only) | sandbox is per chat | rebuild from the newest tarball + patches + the Project doc; keep `claude/snow-hyprland.txt` current after every change |
| `sed` rename of an id hit another component with the same id | blind regex on a big file | edit with exact-match + assert (count must be 1), then re-check for duplicate ids |

## 5. Do
- Work in the repo (working copy), update `docs/narrative.txt` (next entry number) and `docs/Instruction.md`, run `bash docs/make-doc.sh`, then `project_write` the new `docs/snow-hyprland.txt` into the Project.
- **Delivery (owner's choice since 2026-10-14):** he does not want a new tarball for every change. Send paste-in terminal commands (a one-line `sed` for tiny edits, a small patch `.tar.gz` of only the changed files for bigger ones, with one copy command). Send the full `Snow-Dot-vNN.tar.gz` only when he asks for it, and keep every change in the working copy / Project doc so the tarball can be built at any time.
- Give the owner copy-paste commands with one line of explanation; ask at most one question; decide small things yourself and say what you chose.
- Syntax-check: `bash -n` for scripts, bracket balance for QML; check icon code points against the font; test scripts in the sandbox with a fake HOME when possible.
- Add recovery lines for anything that can lock him out (TTY: Ctrl+Alt+F3, `pkill hyprlock`).
- Keep scripts re-runnable and never overwrite his saved settings.
- Verify facts that can change (package names, Hyprland / Quickshell syntax) before using them.

## 6. Do not
- Do not add the features he declined (list in narrative.txt "THINGS THE USER DID NOT WANT"); no lock button in the power menu; never bind Super+L (LocalSend).
- Do not use other people's dotfiles, do not give git commands (he uploads by hand). Colours in QML: Theme tokens only. Allowed exceptions: white `"#ffffff"` on accent / danger, plain `Qt.rgba(0, 0, 0, x)` veils, the fixed red of the Shut Down tile (owner's request) and the neutral dark of the workspace badge.
- Do not draw icons with Canvas any more; use the bundled Material Symbols font by code point.
- Do not assume the sandbox can run Hyprland, Quickshell or sudo.
- Do not delete or overwrite his live settings without a backup.

## 7. Restarting on a new account (what the owner does)
1. Create a Project (for example "Hyprland") and attach: the newest `Snow-Dot-vNN.tar.gz` (or its `docs/` files, including `snow-hyprland.txt`).
2. Start a chat inside it and send:
   > Read `docs/START-HERE.md` and `docs/BUILDER-GUIDE.md` (in the Project or inside the tarball). This is my snow desktop project (Arch + Hyprland + Quickshell). First tell me in 5 lines what you understood and what is untested. Then [the new task].
3. To get the files onto the PC: `tar xzf "$(find ~ -name 'Snow-Dot-vNN.tar.gz' -print -quit)" -C ~` then `bash ~/Snow-Dot/install.sh`; health check `bash ~/Snow-Dot/tools/doctor.sh | grep -E "WARN|FAIL|PASS:"`.
4. A new AI cannot see the PC. When something fails it must ask for the exact output (`tail -30 /tmp/qs.log` after the restart command, `hyprctl configerrors`, `tools/doctor.sh`), not guess.

## 8. Open items
- `kitten failed with error: exit status 1` after a restore (not reproduced).
- Bluetooth mouse wake; SDDM icons do not use the icon font.
- hyprlock look was only generated, never seen by the AI (the owner can preview with `hyprlock`).
- Untested on the real screen (written in the sandbox only): Quick Settings v8 look, new Power menu, Workspace badge, Personalisation menu (incl. the rounded wallpaper picture), mpv-setup.sh on a clean Arch.
