#!/bin/bash
# docs/snow-hyprland.txt is built from:  docs/narrative.txt  +  the full code of every file (appendix)
# Run:  bash docs/make-doc.sh      (tools/snapshot.sh runs this by itself)
D="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$D/docs/snow-hyprland.txt"
cd "$D" || exit 1

dest() {   # install location of a files/... path
  case "$1" in
    files/quickshell/*)        echo "~/.config/quickshell/snow/${1#files/quickshell/}" ;;
    files/snow/*)              echo "~/.config/snow/${1#files/snow/}" ;;
    files/systemd/user/*)      echo "~/.config/systemd/user/${1#files/systemd/user/}" ;;
    files/hypr/*)              echo "~/.config/hypr/${1#files/hypr/}" ;;
    files/sddm/snow/*)         echo "/usr/share/sddm/themes/snow/${1#files/sddm/snow/}" ;;
    files/system/*.service|files/system/*.path) echo "/etc/systemd/system/$(basename "$1")  (__HOME__ -> your home)" ;;
    files/system/snow-sddm-wallpaper) echo "/usr/local/bin/snow-sddm-wallpaper  (__HOME__ -> your home)" ;;
    files/extras/*)            echo "(reference only, install.sh does not copy this)" ;;
    *)                         echo "(stays in this folder, not copied to the system)" ;;
  esac
}

list=$( { ls install.sh tools/*.sh tools/README.md README.txt docs/make-doc.sh 2>/dev/null
          find files -type f ! -path 'files/wallpaper/*' | sort; } | while read -r f; do
          grep -Iq . "$f" 2>/dev/null && echo "$f"; done )

{
  cat docs/narrative.txt
  echo
  echo
  echo "################################################################################"
  echo "#  APPENDIX - FULL CODE OF EVERY FILE"
  echo "#  Generated: $(date '+%F %T')      Files: $(echo "$list" | wc -l)"
  echo "################################################################################"
  echo
  echo "INDEX (file  ->  where it goes on the system):"
  echo
  n=0
  while read -r f; do
    n=$((n+1)); printf '  %2d. %-52s -> %s\n' "$n" "$f" "$(dest "$f")"
  done <<< "$list"
  while read -r f; do
    echo
    echo
    echo "================================================================================"
    echo "FILE: $f      ($(wc -l < "$f") lines)"
    echo "GOES TO: $(dest "$f")"
    echo "================================================================================"
    cat "$f"
  done <<< "$list"
  echo
  echo "================================================================================"
  echo "END OF docs/snow-hyprland.txt"
  echo "================================================================================"
} > "$OUT"
