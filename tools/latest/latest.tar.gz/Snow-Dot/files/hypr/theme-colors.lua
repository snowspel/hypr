return {
    active1  = "rgba(3e4954ee)",
    active2  = "rgba(81888fee)",
    inactive = "rgba(212327aa)",
    glow     = "rgba(3e495466)",
}
