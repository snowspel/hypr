#
# ~/.bashrc
#

# If not running interactively, don't do anything
[[ $- != *i* ]] && return

alias ls='ls --color=auto'
alias grep='grep --color=auto'
PS1='[\u@\h \W]\$ '
alias snow='qs -p ~/.config/quickshell/snow'
[ -f ~/.config/snow/prompt.sh ] && . ~/.config/snow/prompt.sh
